#ifndef ETYPES
#define ETYPES

enum etypes{EDG, ER, EVS};
#endif